"use client"

import { useMemo } from "react"
import { Download } from "lucide-react"
import { AppShell } from "@/components/app-shell"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { KpiCardSkeleton, TableSkeleton } from "@/components/skeleton-loader"
import { useItems, useCampanhas } from "@/hooks/use-data"
import { formatCurrency, formatPercentage } from "@/lib/format"

interface MonthlySummary {
  mes: string
  mesDisplay: string
  receita: number
  despesas: number
  taxas: number
  saldo: number
  roiMedio: number
}

const monthNames = [
  "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
  "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
]

export default function RelatoriosPage() {
  const { data: items, isLoading: itemsLoading } = useItems()
  const { data: campanhas, isLoading: campanhasLoading } = useCampanhas()

  const isLoading = itemsLoading || campanhasLoading

  const monthlySummaries = useMemo(() => {
    if (!items) return []

    const summaryMap = new Map<string, MonthlySummary>()

    items.forEach((item) => {
      const date = new Date(item.data)
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
      
      if (!summaryMap.has(key)) {
        summaryMap.set(key, {
          mes: key,
          mesDisplay: `${monthNames[date.getMonth()]} ${date.getFullYear()}`,
          receita: 0,
          despesas: 0,
          taxas: 0,
          saldo: 0,
          roiMedio: 0,
        })
      }

      const summary = summaryMap.get(key)!
      if (item.tipo === "entrada") {
        summary.receita += Math.abs(item.valorTotal)
        summary.taxas += item.taxaShopee || 0
      } else {
        summary.despesas += Math.abs(item.valorTotal)
      }
    })

    // Calculate saldo and ROI
    summaryMap.forEach((summary, key) => {
      summary.saldo = summary.receita - summary.despesas - summary.taxas

      // Calculate average ROI for campaigns in this month
      if (campanhas) {
        const monthCampanhas = campanhas.filter((c) => {
          const cDate = new Date(c.data)
          const cKey = `${cDate.getFullYear()}-${String(cDate.getMonth() + 1).padStart(2, "0")}`
          return cKey === key
        })
        
        if (monthCampanhas.length > 0) {
          summary.roiMedio = monthCampanhas.reduce((sum, c) => sum + c.roi, 0) / monthCampanhas.length
        }
      }
    })

    return Array.from(summaryMap.values())
      .sort((a, b) => b.mes.localeCompare(a.mes))
  }, [items, campanhas])

  const exportToCSV = () => {
    if (monthlySummaries.length === 0) return

    const headers = ["Mês", "Receita", "Despesas", "Taxas", "Saldo", "ROI Médio (%)"]
    const rows = monthlySummaries.map((s) => [
      s.mesDisplay,
      s.receita.toFixed(2).replace(".", ","),
      s.despesas.toFixed(2).replace(".", ","),
      s.taxas.toFixed(2).replace(".", ","),
      s.saldo.toFixed(2).replace(".", ","),
      s.roiMedio.toFixed(2).replace(".", ","),
    ])

    const csvContent = [
      headers.join(";"),
      ...rows.map((row) => row.join(";")),
    ].join("\n")

    const blob = new Blob(["\ufeff" + csvContent], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `relatorio-mensal-${new Date().toISOString().split("T")[0]}.csv`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  return (
    <AppShell>
      <div className="container mx-auto px-4 py-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Relatórios</h1>
            <p className="text-muted-foreground">Resumo mensal da sua loja</p>
          </div>
          <Button
            onClick={exportToCSV}
            disabled={isLoading || monthlySummaries.length === 0}
            className="gap-2"
          >
            <Download className="h-4 w-4" />
            Exportar CSV
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <KpiCardSkeleton />
              <KpiCardSkeleton />
              <KpiCardSkeleton />
            </div>
            <TableSkeleton rows={6} />
          </div>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle>Resumo Mensal</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Mês</TableHead>
                      <TableHead className="text-right">Receita</TableHead>
                      <TableHead className="text-right">Despesas</TableHead>
                      <TableHead className="text-right">Taxas</TableHead>
                      <TableHead className="text-right">Saldo</TableHead>
                      <TableHead className="text-right">ROI Médio</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {monthlySummaries.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          Nenhum dado disponível
                        </TableCell>
                      </TableRow>
                    ) : (
                      monthlySummaries.map((summary) => (
                        <TableRow key={summary.mes}>
                          <TableCell className="font-medium">
                            {summary.mesDisplay}
                          </TableCell>
                          <TableCell className="text-right">
                            {formatCurrency(summary.receita)}
                          </TableCell>
                          <TableCell className="text-right text-destructive">
                            -{formatCurrency(summary.despesas)}
                          </TableCell>
                          <TableCell className="text-right text-muted-foreground">
                            {summary.taxas > 0 ? formatCurrency(summary.taxas) : "-"}
                          </TableCell>
                          <TableCell className="text-right">
                            <span className={`font-medium ${summary.saldo >= 0 ? "text-success" : "text-destructive"}`}>
                              {summary.saldo >= 0 ? "+" : ""}{formatCurrency(summary.saldo)}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <span className={
                              summary.roiMedio >= 100 ? "text-success" :
                              summary.roiMedio >= 0 ? "text-warning" :
                              "text-destructive"
                            }>
                              {summary.roiMedio > 0 ? formatPercentage(summary.roiMedio) : "-"}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </AppShell>
  )
}
