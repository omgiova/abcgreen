"use client"

import { useMemo } from "react"
import { TrendingUp, Award, Wallet, ArrowUpRight } from "lucide-react"
import { AppShell } from "@/components/app-shell"
import { ROIForm } from "@/components/roi-form"
import { CampaignsTable } from "@/components/campaigns-table"
import { KpiCard } from "@/components/kpi-card"
import { KpiCardSkeleton, TableSkeleton } from "@/components/skeleton-loader"
import { useCampanhas } from "@/hooks/use-data"
import { formatCurrency, formatPercentage } from "@/lib/format"

export default function ROIPage() {
  const { data: campanhas, isLoading, error } = useCampanhas()

  const kpis = useMemo(() => {
    if (!campanhas || campanhas.length === 0) {
      return {
        roiMedio: 0,
        melhorCampanha: "-",
        totalInvestido: 0,
        totalRetornado: 0,
      }
    }

    const roiMedio = campanhas.reduce((sum, c) => sum + c.roi, 0) / campanhas.length
    const melhor = campanhas.reduce((best, c) => c.roi > best.roi ? c : best)
    const totalInvestido = campanhas.reduce((sum, c) => sum + c.investimentoAnuncio, 0)
    const totalRetornado = campanhas.reduce((sum, c) => sum + c.lucroGerado, 0)

    return {
      roiMedio,
      melhorCampanha: melhor.descricao,
      totalInvestido,
      totalRetornado,
    }
  }, [campanhas])

  return (
    <AppShell>
      <div className="container mx-auto px-4 py-6 space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">ROI de Anúncios</h1>
          <p className="text-muted-foreground">Acompanhe o retorno das suas campanhas</p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {isLoading ? (
            <>
              <KpiCardSkeleton />
              <KpiCardSkeleton />
              <KpiCardSkeleton />
              <KpiCardSkeleton />
            </>
          ) : (
            <>
              <KpiCard
                title="ROI Médio"
                value={formatPercentage(kpis.roiMedio)}
                icon={<TrendingUp className="h-5 w-5" />}
              />
              <KpiCard
                title="Melhor Campanha"
                value={kpis.melhorCampanha.length > 20 
                  ? kpis.melhorCampanha.substring(0, 20) + "..." 
                  : kpis.melhorCampanha}
                icon={<Award className="h-5 w-5" />}
              />
              <KpiCard
                title="Total Investido"
                value={formatCurrency(kpis.totalInvestido)}
                icon={<Wallet className="h-5 w-5" />}
              />
              <KpiCard
                title="Total Retornado"
                value={formatCurrency(kpis.totalRetornado)}
                icon={<ArrowUpRight className="h-5 w-5" />}
              />
            </>
          )}
        </div>

        <ROIForm />

        <div className="space-y-4">
          <h2 className="text-lg font-semibold">Histórico de Campanhas</h2>
          {isLoading ? (
            <TableSkeleton rows={5} />
          ) : error ? (
            <p className="text-destructive text-center py-8">
              Erro ao carregar campanhas. Verifique a configuração da API.
            </p>
          ) : (
            <CampaignsTable campanhas={campanhas || []} />
          )}
        </div>
      </div>
    </AppShell>
  )
}
