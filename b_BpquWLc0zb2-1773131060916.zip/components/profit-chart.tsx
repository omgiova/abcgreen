"use client"

import { useMemo } from "react"
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { formatCurrency } from "@/lib/format"
import type { Item } from "@/lib/types"

interface ProfitChartProps {
  items: Item[]
}

const monthNames = [
  "Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
  "Jul", "Ago", "Set", "Out", "Nov", "Dez"
]

export function ProfitChart({ items }: ProfitChartProps) {
  const chartData = useMemo(() => {
    // Mapa: mês -> { receita, despesa, taxa }
    const monthlyData = new Map<string, { receita: number; despesa: number; taxas: number }>()

    items.forEach((item) => {
      const date = new Date(item.data)
      const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
      
      const current = monthlyData.get(key) || { receita: 0, despesa: 0, taxas: 0 }
      
      if (item.tipo === "entrada") {
        current.receita += Math.abs(item.valorTotal)
        current.taxas += item.taxaShopee || 0
      } else {
        current.despesa += Math.abs(item.valorTotal)
      }
      
      monthlyData.set(key, current)
    })

    const sortedMonths = Array.from(monthlyData.entries())
      .sort((a, b) => a[0].localeCompare(b[0]))
      .slice(-12)

    return sortedMonths.map(([key, data]) => {
      const [year, month] = key.split("-")
      const saldo = data.receita - data.despesa - data.taxas
      return {
        name: `${monthNames[parseInt(month) - 1]}/${year.slice(2)}`,
        receita: data.receita,
        despesa: data.despesa,
        saldo,
      }
    })
  }, [items])

  if (chartData.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Saldo por Mês</CardTitle>
        </CardHeader>
        <CardContent className="flex h-64 items-center justify-center text-muted-foreground">
          Nenhum dado disponível
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Saldo por Mês</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
            <XAxis
              dataKey="name"
              tick={{ fontSize: 12 }}
              tickLine={false}
              axisLine={false}
              className="fill-muted-foreground"
            />
            <YAxis
              tick={{ fontSize: 12 }}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `R$${(value / 1000).toFixed(0)}k`}
              className="fill-muted-foreground"
            />
            <Tooltip
              content={({ active, payload }) => {
                if (!active || !payload?.length) return null
                const data = payload[0].payload
                return (
                  <div className="rounded-lg border bg-background p-3 shadow-sm">
                    <div className="text-sm font-medium mb-2">
                      {data.name}
                    </div>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">Receita:</span>
                        <span className="text-success font-medium">+{formatCurrency(data.receita)}</span>
                      </div>
                      <div className="flex justify-between gap-4">
                        <span className="text-muted-foreground">Despesa:</span>
                        <span className="text-destructive font-medium">-{formatCurrency(data.despesa)}</span>
                      </div>
                      <div className="flex justify-between gap-4 pt-1 border-t">
                        <span className="font-medium">Saldo:</span>
                        <span className={`font-medium ${data.saldo >= 0 ? "text-success" : "text-destructive"}`}>
                          {formatCurrency(data.saldo)}
                        </span>
                      </div>
                    </div>
                  </div>
                )
              }}
            />
            <Bar
              dataKey="saldo"
              fill="hsl(var(--primary))"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}
