"use client"

import { useState, useMemo } from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { formatCurrency, formatDate } from "@/lib/format"
import type { Item, FormaPagamento, TipoTransacao } from "@/lib/types"

interface TransactionsTableProps {
  items: Item[]
}

const formasPagamento: { value: FormaPagamento | "todos"; label: string }[] = [
  { value: "todos", label: "Todas" },
  { value: "pix", label: "PIX" },
  { value: "credito", label: "Crédito" },
  { value: "debito", label: "Débito" },
  { value: "boleto", label: "Boleto" },
  { value: "dinheiro", label: "Dinheiro" },
]

const tiposTransacao: { value: TipoTransacao | "todos"; label: string }[] = [
  { value: "todos", label: "Todos" },
  { value: "entrada", label: "Entrada" },
  { value: "saida", label: "Saída" },
]

export function TransactionsTable({ items }: TransactionsTableProps) {
  const [dateFrom, setDateFrom] = useState("")
  const [dateTo, setDateTo] = useState("")
  const [formaPagamento, setFormaPagamento] = useState<FormaPagamento | "todos">("todos")
  const [tipo, setTipo] = useState<TipoTransacao | "todos">("todos")

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      if (dateFrom && item.data < dateFrom) return false
      if (dateTo && item.data > dateTo) return false
      if (formaPagamento !== "todos" && item.formaPagamento !== formaPagamento) return false
      if (tipo !== "todos" && item.tipo !== tipo) return false
      return true
    })
  }, [items, dateFrom, dateTo, formaPagamento, tipo])

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">De:</span>
          <Input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="w-auto"
          />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Até:</span>
          <Input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="w-auto"
          />
        </div>
        <Select
          value={formaPagamento}
          onValueChange={(v) => setFormaPagamento(v as FormaPagamento | "todos")}
        >
          <SelectTrigger className="w-[140px]">
            <SelectValue placeholder="Pagamento" />
          </SelectTrigger>
          <SelectContent>
            {formasPagamento.map((fp) => (
              <SelectItem key={fp.value} value={fp.value}>
                {fp.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={tipo}
          onValueChange={(v) => setTipo(v as TipoTransacao | "todos")}
        >
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="Tipo" />
          </SelectTrigger>
          <SelectContent>
            {tiposTransacao.map((t) => (
              <SelectItem key={t.value} value={t.value}>
                {t.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Data</TableHead>
              <TableHead>Nome</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead>Pagamento</TableHead>
              <TableHead className="text-right">Valor</TableHead>
              <TableHead className="text-right">Taxa Shopee</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredItems.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                  Nenhuma transação encontrada
                </TableCell>
              </TableRow>
            ) : (
              filteredItems.map((item) => {
                const isEntrada = item.tipo === "entrada"
                const valorDisplay = Math.abs(item.valorTotal)
                
                return (
                  <TableRow
                    key={item.id}
                    className={cn(
                      isEntrada
                        ? "bg-success/5 hover:bg-success/10"
                        : "bg-destructive/5 hover:bg-destructive/10"
                    )}
                  >
                    <TableCell className="font-medium">
                      {formatDate(item.data)}
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{item.nome}</div>
                        {item.nomeComprador && (
                          <div className="text-xs text-muted-foreground">
                            {item.nomeComprador}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={isEntrada ? "default" : "destructive"}
                        className={cn(
                          isEntrada
                            ? "bg-success text-success-foreground"
                            : ""
                        )}
                      >
                        {isEntrada ? "Entrada" : "Saída"}
                      </Badge>
                    </TableCell>
                    <TableCell className="capitalize">
                      {item.formaPagamento}
                    </TableCell>
                    <TableCell className="text-right">
                      <span className={cn(
                        "font-medium",
                        isEntrada ? "text-success" : "text-destructive"
                      )}>
                        {isEntrada ? "+" : "-"}{formatCurrency(valorDisplay)}
                      </span>
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">
                      {item.taxaShopee > 0 ? formatCurrency(item.taxaShopee) : "-"}
                    </TableCell>
                  </TableRow>
                )
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
