"use client"

import { useState, useMemo } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Field, FieldLabel, FieldGroup } from "@/components/ui/field"
import { Spinner } from "@/components/ui/spinner"
import { useToast } from "@/hooks/use-toast"
import { createItem } from "@/lib/api"
import {
  formatCurrency,
  formatPercentage,
  calculateTaxaShopee,
  calculateCustoPorProduto,
} from "@/lib/format"
import type { FormaPagamento, TipoTransacao } from "@/lib/types"
import { mutate } from "swr"
import { ArrowDownCircle, ArrowUpCircle, Calculator } from "lucide-react"

interface FormData {
  data: string
  nome: string
  descricao: string
  quantidade: string
  local: string
  formaPagamento: FormaPagamento | ""
  nomeComprador: string
  tipo: TipoTransacao | ""
  valorTotal: string
}

// Calculadora auxiliar separada
interface CalculadoraData {
  valorGastoItem: string
  qtdProdutosFabricados: string
}

interface FormErrors {
  [key: string]: string
}

const initialFormData: FormData = {
  data: new Date().toISOString().split("T")[0],
  nome: "",
  descricao: "",
  quantidade: "1",
  local: "",
  formaPagamento: "",
  nomeComprador: "",
  tipo: "",
  valorTotal: "",
}

const initialCalculadoraData: CalculadoraData = {
  valorGastoItem: "",
  qtdProdutosFabricados: "",
}

export function TransactionForm() {
  const router = useRouter()
  const { toast } = useToast()
  const [formData, setFormData] = useState<FormData>(initialFormData)
  const [calculadoraData, setCalculadoraData] = useState<CalculadoraData>(initialCalculadoraData)
  const [errors, setErrors] = useState<FormErrors>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Cálculos da transação principal (NÃO inclui calculadora auxiliar)
  const transactionCalc = useMemo(() => {
    const valorTotal = parseFloat(formData.valorTotal) || 0
    const isEntrada = formData.tipo === "entrada"
    const taxaShopee = isEntrada ? calculateTaxaShopee(valorTotal) : 0
    const valorFinal = isEntrada ? valorTotal - taxaShopee : valorTotal

    return {
      valorTotal,
      taxaShopee,
      valorFinal,
      isEntrada,
    }
  }, [formData.valorTotal, formData.tipo])

  // Calculadora auxiliar separada (não afeta a transação)
  const custoPorProduto = useMemo(() => {
    const valorGastoItem = parseFloat(calculadoraData.valorGastoItem) || 0
    const qtdProdutosFabricados = parseInt(calculadoraData.qtdProdutosFabricados) || 0
    return calculateCustoPorProduto(valorGastoItem, qtdProdutosFabricados)
  }, [calculadoraData.valorGastoItem, calculadoraData.qtdProdutosFabricados])

  const handleChange = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => {
        const newErrors = { ...prev }
        delete newErrors[field]
        return newErrors
      })
    }
  }

  const handleCalculadoraChange = (field: keyof CalculadoraData, value: string) => {
    setCalculadoraData((prev) => ({ ...prev, [field]: value }))
  }

  const validate = (): boolean => {
    const newErrors: FormErrors = {}

    if (!formData.data) newErrors.data = "Data é obrigatória"
    if (!formData.nome.trim()) newErrors.nome = "Nome é obrigatório"
    if (!formData.quantidade || parseInt(formData.quantidade) < 1) {
      newErrors.quantidade = "Quantidade deve ser pelo menos 1"
    }
    if (!formData.formaPagamento) newErrors.formaPagamento = "Selecione a forma de pagamento"
    if (!formData.tipo) newErrors.tipo = "Selecione o tipo"
    if (!formData.valorTotal || parseFloat(formData.valorTotal) <= 0) {
      newErrors.valorTotal = "Valor deve ser maior que zero"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validate()) return

    setIsSubmitting(true)

    const valorTotal = parseFloat(formData.valorTotal) || 0
    const isEntrada = formData.tipo === "entrada"
    const taxaShopee = isEntrada ? transactionCalc.taxaShopee : 0

    const item = {
      data: formData.data,
      nome: formData.nome,
      descricao: formData.descricao,
      quantidade: parseInt(formData.quantidade) || 1,
      local: formData.local,
      formaPagamento: formData.formaPagamento as FormaPagamento,
      nomeComprador: formData.nomeComprador,
      tipo: formData.tipo as TipoTransacao,
      // Valor positivo para entrada, negativo para saída
      valorTotal: isEntrada ? valorTotal : -Math.abs(valorTotal),
      taxaShopee: taxaShopee,
    }

    const success = await createItem(item)

    setIsSubmitting(false)

    if (success) {
      toast({
        title: "Sucesso!",
        description: "Transação adicionada com sucesso.",
      })
      mutate("items")
      router.push("/")
    } else {
      toast({
        title: "Erro",
        description: "Não foi possível adicionar a transação. Verifique a configuração da API.",
        variant: "destructive",
      })
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Seletor de Tipo - Destaque no topo */}
      <Card>
        <CardHeader>
          <CardTitle>Tipo de Transação</CardTitle>
          <CardDescription>Selecione se é uma entrada (venda) ou saída (despesa)</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <button
              type="button"
              onClick={() => handleChange("tipo", "entrada")}
              className={`flex flex-col items-center gap-2 rounded-lg border-2 p-4 transition-all ${formData.tipo === "entrada"
                ? "border-success bg-success/10 text-success"
                : "border-border hover:border-success/50"
                }`}
            >
              <ArrowDownCircle className="h-8 w-8" />
              <span className="font-semibold">Entrada</span>
              <span className="text-xs text-muted-foreground">Venda / Receita</span>
            </button>
            <button
              type="button"
              onClick={() => handleChange("tipo", "saida")}
              className={`flex flex-col items-center gap-2 rounded-lg border-2 p-4 transition-all ${formData.tipo === "saida"
                ? "border-destructive bg-destructive/10 text-destructive"
                : "border-border hover:border-destructive/50"
                }`}
            >
              <ArrowUpCircle className="h-8 w-8" />
              <span className="font-semibold">Saída</span>
              <span className="text-xs text-muted-foreground">Despesa / Custo</span>
            </button>
          </div>
          {errors.tipo && <p className="mt-2 text-center text-sm text-destructive">{errors.tipo}</p>}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Informações da Transação</CardTitle>
        </CardHeader>
        <CardContent>
          <FieldGroup className="grid gap-4 sm:grid-cols-2">
            <Field>
              <FieldLabel>Data</FieldLabel>
              <Input
                type="date"
                value={formData.data}
                onChange={(e) => handleChange("data", e.target.value)}
              />
              {errors.data && <p className="text-sm text-destructive">{errors.data}</p>}
            </Field>

            <Field>
              <FieldLabel>Nome do Item/Produto</FieldLabel>
              <Input
                placeholder="Ex: Jardineira 40cm"
                value={formData.nome}
                onChange={(e) => handleChange("nome", e.target.value)}
              />
              {errors.nome && <p className="text-sm text-destructive">{errors.nome}</p>}
            </Field>

            <Field className="sm:col-span-2">
              <FieldLabel>Descrição</FieldLabel>
              <Textarea
                placeholder="Descrição detalhada do produto ou serviço"
                value={formData.descricao}
                onChange={(e) => handleChange("descricao", e.target.value)}
              />
            </Field>

            <Field>
              <FieldLabel>Quantidade</FieldLabel>
              <Input
                type="number"
                min="1"
                value={formData.quantidade}
                onChange={(e) => handleChange("quantidade", e.target.value)}
              />
              {errors.quantidade && <p className="text-sm text-destructive">{errors.quantidade}</p>}
            </Field>

            <Field>
              <FieldLabel>Local</FieldLabel>
              <Input
                placeholder="Ex: Shopee, Mercado Livre"
                value={formData.local}
                onChange={(e) => handleChange("local", e.target.value)}
              />
            </Field>

            <Field>
              <FieldLabel>Forma de Pagamento</FieldLabel>
              <Select
                value={formData.formaPagamento}
                onValueChange={(v) => handleChange("formaPagamento", v)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pix">PIX</SelectItem>
                  <SelectItem value="credito">Crédito</SelectItem>
                  <SelectItem value="debito">Débito</SelectItem>
                  <SelectItem value="boleto">Boleto</SelectItem>
                  <SelectItem value="dinheiro">Dinheiro</SelectItem>
                </SelectContent>
              </Select>
              {errors.formaPagamento && <p className="text-sm text-destructive">{errors.formaPagamento}</p>}
            </Field>

            <Field>
              <FieldLabel>Nome do Comprador/Fornecedor</FieldLabel>
              <Input
                placeholder={formData.tipo === "saida" ? "Nome do fornecedor" : "Nome do cliente"}
                value={formData.nomeComprador}
                onChange={(e) => handleChange("nomeComprador", e.target.value)}
              />
            </Field>

            <Field className="sm:col-span-2">
              <FieldLabel>Valor Total (R$)</FieldLabel>
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="0,00"
                value={formData.valorTotal}
                onChange={(e) => handleChange("valorTotal", e.target.value)}
                className="text-lg"
              />
              {errors.valorTotal && <p className="text-sm text-destructive">{errors.valorTotal}</p>}
            </Field>
          </FieldGroup>
        </CardContent>
      </Card>

      {/* Preview do valor a ser registrado */}
      {formData.tipo && formData.valorTotal && (
        <Card className={formData.tipo === "entrada" ? "border-success/50 bg-success/5" : "border-destructive/50 bg-destructive/5"}>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Resumo da Transação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Valor informado:</span>
                <span className="font-medium">{formatCurrency(transactionCalc.valorTotal)}</span>
              </div>

              {formData.tipo === "entrada" && transactionCalc.taxaShopee > 0 && (
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Taxa Shopee (14%):</span>
                  <span className="text-destructive">-{formatCurrency(transactionCalc.taxaShopee)}</span>
                </div>
              )}

              <div className="border-t pt-3">
                <div className="flex items-center justify-between">
                  <span className="font-medium">Valor a registrar:</span>
                  <span className={`text-xl font-bold ${formData.tipo === "entrada" ? "text-success" : "text-destructive"}`}>
                    {formData.tipo === "entrada" ? "+" : "-"}{formatCurrency(transactionCalc.valorFinal)}
                  </span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Calculadora auxiliar - NÃO afeta os cálculos da transação */}
      <Card className="border-dashed">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Calculator className="h-5 w-5 text-muted-foreground" />
            <CardTitle className="text-base">Calculadora Auxiliar</CardTitle>
          </div>
          <CardDescription>
            Ferramenta para calcular custo por produto. Este valor NÃO é incluído na transação.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <FieldGroup className="grid gap-4 sm:grid-cols-2">
            <Field>
              <FieldLabel>Valor gasto no insumo (R$)</FieldLabel>
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="0,00"
                value={calculadoraData.valorGastoItem}
                onChange={(e) => handleCalculadoraChange("valorGastoItem", e.target.value)}
              />
            </Field>

            <Field>
              <FieldLabel>Qtd de produtos fabricados</FieldLabel>
              <Input
                type="number"
                min="0"
                placeholder="0"
                value={calculadoraData.qtdProdutosFabricados}
                onChange={(e) => handleCalculadoraChange("qtdProdutosFabricados", e.target.value)}
              />
            </Field>
          </FieldGroup>

          <div className="mt-4 rounded-lg bg-muted p-4">
            <p className="text-sm text-muted-foreground">Custo por produto:</p>
            <p className="text-2xl font-bold text-primary">
              {formatCurrency(custoPorProduto)}
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Use este valor como referência para precificação
            </p>
          </div>
        </CardContent>
      </Card>

      <Button type="submit" className="w-full" disabled={isSubmitting}>
        {isSubmitting ? (
          <>
            <Spinner className="mr-2 h-4 w-4" />
            Salvando...
          </>
        ) : (
          "Salvar Transação"
        )}
      </Button>
    </form>
  )
}
