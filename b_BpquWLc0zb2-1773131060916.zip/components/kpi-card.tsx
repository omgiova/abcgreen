import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface KpiCardProps {
  title: string
  value: string
  icon?: React.ReactNode
  className?: string
  valueClassName?: string
  trend?: {
    value: number
    isPositive: boolean
  }
}

export function KpiCard({ title, value, icon, className, valueClassName, trend }: KpiCardProps) {
  return (
    <Card className={cn("", className)}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        {icon && (
          <div className="text-primary">
            {icon}
          </div>
        )}
      </CardHeader>
      <CardContent>
        <div className={cn("text-2xl font-bold", valueClassName)}>{value}</div>
        {trend && (
          <p className={cn(
            "mt-1 text-xs",
            trend.isPositive ? "text-success" : "text-destructive"
          )}>
            {trend.isPositive ? "+" : ""}{trend.value.toFixed(2)}% em relação ao mês anterior
          </p>
        )}
      </CardContent>
    </Card>
  )
}
