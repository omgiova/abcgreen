"use client"

import { useMemo } from "react"
import { DollarSign, TrendingUp, ShoppingCart, ArrowDownUp } from "lucide-react"
import { useItems } from "@/hooks/use-data"
import { KpiCard } from "./kpi-card"
import { KpiCardSkeleton, TableSkeleton, ChartSkeleton } from "./skeleton-loader"
import { ProfitChart } from "./profit-chart"
import { TransactionsTable } from "./transactions-table"
import { formatCurrency } from "@/lib/format"

export function Dashboard() {
  const { data: items, isLoading, error } = useItems()

  const kpis = useMemo(() => {
    if (!items || items.length === 0) {
      return {
        receitaTotal: 0,
        despesaTotal: 0,
        saldoLiquido: 0,
        numVendas: 0,
      }
    }

    // Entradas são valores positivos, saídas são valores negativos
    const entradas = items.filter((item) => item.tipo === "entrada")
    const saidas = items.filter((item) => item.tipo === "saida")
    
    // Receita total (entradas brutas)
    const receitaTotal = entradas.reduce((sum, item) => sum + Math.abs(item.valorTotal), 0)
    
    // Despesa total (saídas)
    const despesaTotal = saidas.reduce((sum, item) => sum + Math.abs(item.valorTotal), 0)
    
    // Saldo líquido = soma de todos os valores (positivos - negativos - taxas)
    const taxasTotal = entradas.reduce((sum, item) => sum + (item.taxaShopee || 0), 0)
    const saldoLiquido = receitaTotal - despesaTotal - taxasTotal
    
    const numVendas = entradas.length

    return {
      receitaTotal,
      despesaTotal,
      saldoLiquido,
      numVendas,
    }
  }, [items])

  if (error) {
    return (
      <div className="flex h-64 items-center justify-center">
        <p className="text-destructive">Erro ao carregar dados. Verifique a configuração da API.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Visão geral da sua loja Shopee</p>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {isLoading ? (
          <>
            <KpiCardSkeleton />
            <KpiCardSkeleton />
            <KpiCardSkeleton />
            <KpiCardSkeleton />
          </>
        ) : (
          <>
            <KpiCard
              title="Receita Total"
              value={formatCurrency(kpis.receitaTotal)}
              icon={<DollarSign className="h-5 w-5" />}
              valueClassName="text-success"
            />
            <KpiCard
              title="Despesas"
              value={formatCurrency(kpis.despesaTotal)}
              icon={<ArrowDownUp className="h-5 w-5" />}
              valueClassName="text-destructive"
            />
            <KpiCard
              title="Saldo Líquido"
              value={formatCurrency(kpis.saldoLiquido)}
              icon={<TrendingUp className="h-5 w-5" />}
              valueClassName={kpis.saldoLiquido >= 0 ? "text-success" : "text-destructive"}
            />
            <KpiCard
              title="Nº de Vendas"
              value={kpis.numVendas.toString()}
              icon={<ShoppingCart className="h-5 w-5" />}
            />
          </>
        )}
      </div>

      {isLoading ? (
        <ChartSkeleton />
      ) : (
        <ProfitChart items={items || []} />
      )}

      <div className="space-y-4">
        <h2 className="text-lg font-semibold">Transações</h2>
        {isLoading ? (
          <TableSkeleton rows={5} />
        ) : (
          <TransactionsTable items={items || []} />
        )}
      </div>
    </div>
  )
}
