export interface Item {
  id: string
  data: string
  nome: string
  descricao: string
  quantidade: number
  local: string
  formaPagamento: "pix" | "credito" | "debito" | "boleto" | "dinheiro"
  nomeComprador: string
  tipo: "entrada" | "saida"
  // Valor positivo para entrada, negativo para saída
  valorTotal: number
  // Taxa Shopee (apenas para entradas)
  taxaShopee: number
}

export interface CampanhaROI {
  id: string
  data: string
  descricao: string
  investimentoAnuncio: number
  lucroGerado: number
  roi: number
}

export type FormaPagamento = "pix" | "credito" | "debito" | "boleto" | "dinheiro"
export type TipoTransacao = "entrada" | "saida"
